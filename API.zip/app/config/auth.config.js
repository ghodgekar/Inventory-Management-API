module.exports = {
  secret: "gosarthii-secret-key"
};